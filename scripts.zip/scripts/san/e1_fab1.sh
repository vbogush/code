#!/bin/bash
ssh -T plp14997@dee1sans11ccpl1 << 'ENDSSH'
alicreate "dee1vsa091ccpx1_F1_1","10:00:00:10:9b:1d:95:af"
alicreate "dee1vsa091ccpx1_F1_2","10:00:00:10:9b:1d:95:b0"
alicreate "dee1vsb091ccpx1_F1_1","10:00:00:10:9b:1d:95:64"
alicreate "dee1vsb091ccpx1_F1_2","10:00:00:10:9b:1d:95:65"
alicreate "dee1vsa101ccpx1_F1_1","10:00:00:10:9b:1d:30:64"
alicreate "dee1vsa101ccpx1_F1_2","10:00:00:10:9b:1d:30:65"
alicreate "dee1vsb101ccpx1_F1_1","10:00:00:10:9b:1d:35:f3"
alicreate "dee1vsb101ccpx1_F1_2","10:00:00:10:9b:1d:35:f4"
zonecreate "dee1vsa091ccpx1_F1_1_SVC2_IO1","dee1vsa091ccpx1_F1_1;dee1svcs31ccpl1_n3a5p1;dee1svcs31ccpl1_n4a5p3"
zonecreate "dee1vsa091ccpx1_F1_2_SVC2_IO1","dee1vsa091ccpx1_F1_2;dee1svcs31ccpl1_n3a5p1;dee1svcs31ccpl1_n4a5p3"
zonecreate "dee1vsb091ccpx1_F1_1_SVC2_IO2","dee1vsb091ccpx1_F1_1;dee1svcs31ccpl1_n5a5p1;dee1svcs31ccpl1_n6a5p3"
zonecreate "dee1vsb091ccpx1_F1_2_SVC2_IO2","dee1vsb091ccpx1_F1_2;dee1svcs31ccpl1_n5a5p1;dee1svcs31ccpl1_n6a5p3"
zonecreate "dee1vsa101ccpx1_F1_1_SVC2_IO1","dee1vsa101ccpx1_F1_1;dee1svcs31ccpl1_n4a5p1;dee1svcs31ccpl1_n3a5p3"
zonecreate "dee1vsa101ccpx1_F1_2_SVC2_IO1","dee1vsa101ccpx1_F1_2;dee1svcs31ccpl1_n4a5p1;dee1svcs31ccpl1_n3a5p3"
zonecreate "dee1vsb101ccpx1_F1_1_SVC2_IO2","dee1vsb101ccpx1_F1_1;dee1svcs31ccpl1_n6a5p1;dee1svcs31ccpl1_n5a5p3"
zonecreate "dee1vsb101ccpx1_F1_2_SVC2_IO2","dee1vsb101ccpx1_F1_2;dee1svcs31ccpl1_n6a5p1;dee1svcs31ccpl1_n5a5p3"
cfgadd "fab1_actual_cfg","dee1vsa091ccpx1_F1_1_SVC2_IO1;dee1vsa091ccpx1_F1_2_SVC2_IO1;dee1vsb091ccpx1_F1_1_SVC2_IO2;dee1vsb091ccpx1_F1_2_SVC2_IO2"
cfgadd "fab1_actual_cfg","dee1vsa101ccpx1_F1_1_SVC2_IO1;dee1vsa101ccpx1_F1_2_SVC2_IO1;dee1vsb101ccpx1_F1_1_SVC2_IO2;dee1vsb101ccpx1_F1_2_SVC2_IO2"
cfgsave -f
ENDSSH
