#!/bin/bash
ssh -T plp14997@fre2sans41ccpl1 << 'ENDSSH'
zonecreate "fre2vsb011ccpx1_F2_1_SVC1_IO3","fre2vsb011ccpx1_F2_1;e2_cp1_svc_n7p2;e2_cp1_svc_n8p4"
zonecreate "fre2vsb011ccpx1_F2_2_SVC1_IO3","fre2vsb011ccpx1_F2_2;e2_cp1_svc_n7p2;e2_cp1_svc_n8p4"
zonecreate "fre2vsb021ccpx1_F2_1_SVC1_IO3","fre2vsb021ccpx1_F2_1;e2_cp1_svc_n7p4;e2_cp1_svc_n8p2"
zonecreate "fre2vsb021ccpx1_F2_2_SVC1_IO3","fre2vsb021ccpx1_F2_2;e2_cp1_svc_n7p4;e2_cp1_svc_n8p2"
zonecreate "fre2vsb031ccpx1_F2_1_SVC1_IO3","fre2vsb031ccpx1_F2_1;e2_cp1_svc_n7p2;e2_cp1_svc_n8p4"
zonecreate "fre2vsb031ccpx1_F2_2_SVC1_IO3","fre2vsb031ccpx1_F2_2;e2_cp1_svc_n7p2;e2_cp1_svc_n8p4"
zonecreate "fre2vsb041ccpx1_F2_1_SVC1_IO3","fre2vsb041ccpx1_F2_1;e2_cp1_svc_n7p4;e2_cp1_svc_n8p2"
zonecreate "fre2vsb041ccpx1_F2_2_SVC1_IO3","fre2vsb041ccpx1_F2_2;e2_cp1_svc_n7p4;e2_cp1_svc_n8p2"
cfgadd "fab2_actual_cfg","fre2vsb011ccpx1_F2_1_SVC1_IO3;fre2vsb011ccpx1_F2_2_SVC1_IO3"
cfgadd "fab2_actual_cfg","fre2vsb021ccpx1_F2_1_SVC1_IO3;fre2vsb021ccpx1_F2_2_SVC1_IO3"
cfgadd "fab2_actual_cfg","fre2vsb031ccpx1_F2_1_SVC1_IO3;fre2vsb031ccpx1_F2_2_SVC1_IO3"
cfgadd "fab2_actual_cfg","fre2vsb041ccpx1_F2_1_SVC1_IO3;fre2vsb041ccpx1_F2_2_SVC1_IO3"
cfgsave -f
ENDSSH
