#!/bin/bash
ssh -T plp14997@fre2sans11ccpl1 << 'ENDSSH'
zonecreate "fre2vsb011ccpx1_F1_1_SVC1_IO3","fre2vsb011ccpx1_F1_1;e2_cp1_svc_n7p1;e2_cp1_svc_n8p3"
zonecreate "fre2vsb011ccpx1_F1_2_SVC1_IO3","fre2vsb011ccpx1_F1_2;e2_cp1_svc_n7p1;e2_cp1_svc_n8p3"
zonecreate "fre2vsb021ccpx1_F1_1_SVC1_IO3","fre2vsb021ccpx1_F1_1;e2_cp1_svc_n7p3;e2_cp1_svc_n8p1"
zonecreate "fre2vsb021ccpx1_F1_2_SVC1_IO3","fre2vsb021ccpx1_F1_2;e2_cp1_svc_n7p3;e2_cp1_svc_n8p1"
zonecreate "fre2vsb031ccpx1_F1_1_SVC1_IO3","fre2vsb031ccpx1_F1_1;e2_cp1_svc_n7p1;e2_cp1_svc_n8p3"
zonecreate "fre2vsb031ccpx1_F1_2_SVC1_IO3","fre2vsb031ccpx1_F1_2;e2_cp1_svc_n7p1;e2_cp1_svc_n8p3"
zonecreate "fre2vsb041ccpx1_F1_1_SVC1_IO3","fre2vsb041ccpx1_F1_1;e2_cp1_svc_n7p3;e2_cp1_svc_n8p1"
zonecreate "fre2vsb041ccpx1_F1_2_SVC1_IO3","fre2vsb041ccpx1_F1_2;e2_cp1_svc_n7p3;e2_cp1_svc_n8p1"
cfgadd "fab1_actual_cfg","fre2vsb011ccpx1_F1_1_SVC1_IO3;fre2vsb011ccpx1_F1_2_SVC1_IO3"
cfgadd "fab1_actual_cfg","fre2vsb021ccpx1_F1_1_SVC1_IO3;fre2vsb021ccpx1_F1_2_SVC1_IO3"
cfgadd "fab1_actual_cfg","fre2vsb031ccpx1_F1_1_SVC1_IO3;fre2vsb031ccpx1_F1_2_SVC1_IO3"
cfgadd "fab1_actual_cfg","fre2vsb041ccpx1_F1_1_SVC1_IO3;fre2vsb041ccpx1_F1_2_SVC1_IO3"
cfgsave -f
ENDSSH
