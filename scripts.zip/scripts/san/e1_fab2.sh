#!/bin/bash
ssh -T plp14997@dee1sans41ccpl1 << 'ENDSSH'
alicreate "dee1vsa091ccpx1_F2_1","10:00:00:10:9b:1c:76:c2"
alicreate "dee1vsa091ccpx1_F2_2","10:00:00:10:9b:1c:76:c3"
alicreate "dee1vsb091ccpx1_F2_1","10:00:00:10:9b:1c:73:11"
alicreate "dee1vsb091ccpx1_F2_2","10:00:00:10:9b:1c:73:12"
alicreate "dee1vsa101ccpx1_F2_1","10:00:00:10:9b:17:e7:4d"
alicreate "dee1vsa101ccpx1_F2_2","10:00:00:10:9b:17:e7:4e"
alicreate "dee1vsb101ccpx1_F2_1","10:00:00:10:9b:1d:b8:6c"
alicreate "dee1vsb101ccpx1_F2_2","10:00:00:10:9b:1d:b8:6d"
zonecreate "dee1vsa091ccpx1_F2_1_SVC2_IO1","dee1vsa091ccpx1_F2_1;dee1svcs31ccpl1_n3a5p2;dee1svcs31ccpl1_n4a5p4"
zonecreate "dee1vsa091ccpx1_F2_2_SVC2_IO1","dee1vsa091ccpx1_F2_2;dee1svcs31ccpl1_n3a5p2;dee1svcs31ccpl1_n4a5p4"
zonecreate "dee1vsb091ccpx1_F2_1_SVC2_IO2","dee1vsb091ccpx1_F2_1;dee1svcs31ccpl1_n5a5p2;dee1svcs31ccpl1_n6a5p4"
zonecreate "dee1vsb091ccpx1_F2_2_SVC2_IO2","dee1vsb091ccpx1_F2_2;dee1svcs31ccpl1_n5a5p2;dee1svcs31ccpl1_n6a5p4"
zonecreate "dee1vsa101ccpx1_F2_1_SVC2_IO1","dee1vsa101ccpx1_F2_1;dee1svcs31ccpl1_n4a5p2;dee1svcs31ccpl1_n3a5p4"
zonecreate "dee1vsa101ccpx1_F2_2_SVC2_IO1","dee1vsa101ccpx1_F2_2;dee1svcs31ccpl1_n4a5p2;dee1svcs31ccpl1_n3a5p4"
zonecreate "dee1vsb101ccpx1_F2_1_SVC2_IO2","dee1vsb101ccpx1_F2_1;dee1svcs31ccpl1_n6a5p2;dee1svcs31ccpl1_n5a5p4"
zonecreate "dee1vsb101ccpx1_F2_2_SVC2_IO2","dee1vsb101ccpx1_F2_2;dee1svcs31ccpl1_n6a5p2;dee1svcs31ccpl1_n5a5p4"
cfgadd "fab2_actual_cfg","dee1vsa091ccpx1_F2_1_SVC2_IO1;dee1vsa091ccpx1_F2_2_SVC2_IO1;dee1vsb091ccpx1_F2_1_SVC2_IO2;dee1vsb091ccpx1_F2_2_SVC2_IO2"
cfgadd "fab2_actual_cfg","dee1vsa101ccpx1_F2_1_SVC2_IO1;dee1vsa101ccpx1_F2_2_SVC2_IO1;dee1vsb101ccpx1_F2_1_SVC2_IO2;dee1vsb101ccpx1_F2_2_SVC2_IO2"
cfgsave -f
ENDSSH
