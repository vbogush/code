#!/bin/bash
for i in {0..215}; do alz_conn.sh $1 lsdrive $i >> v7k_drives_details; done
