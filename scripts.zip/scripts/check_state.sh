#!/bin/bash

cat vdisk_detail | awk '{print$5}' | while read STATE; do

if  [ "$STATE" = "online" ];

 then echo "Online"
 else echo "<<<<<<<$STATE>>>>>>>>"
fi
done
exit 0
