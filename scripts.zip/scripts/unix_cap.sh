#!/bin/bash

for i in `cat unix_host_list.txt`; do echo $i >> n1_un_cap.txt; alz_conn.sh usn1svcs11ccpl1 'lshostvdiskmap -nohdr $i | while read -a X; do lsvdisk ${X[3]} | grep ^capacity; done' >> n1_un_cap.txt; done

