#!/bin/bash

for (( i=0,j=1,k=2; i<=22 && j<=23 && k<=24; i++,j++,k++ ))
do
        echo "fre2_01a_vdisk_v7k_11_sas_600gb_r5_$j $i $k"
done
