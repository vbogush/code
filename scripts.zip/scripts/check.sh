#!/bin/bash

#echo -n "Are you sure you want to use this script? "; read


E1='seccertutil showcsr || printf "y\n" | seccertutil genkey -keysize 2048; seccertutil gencsr -hash sha1 -country DE -state Darmstadt -locality Frankfurt -org Allianz -orgunit Storage -cn NAME.sma.cmsalz.ibm.allianz && seccertutil showcsr'
E2='seccertutil showcsr || printf "y\n" | seccertutil genkey -keysize 2048; seccertutil gencsr -hash sha1 -country FR -state Ile-de-France -locality Paris -org Allianz -orgunit Storage -cn NAME.sma.cmsalz.ibm.allianz && seccertutil showcsr'
N1='seccertutil showcsr || printf "y\n" | seccertutil genkey -keysize 2048; seccertutil gencsr -hash sha1 -country US -state Arizona -locality Phoenix -org Allianz -orgunit Storage -cn NAME.sma.cmsalz.ibm.allianz && seccertutil showcsr'
N2='seccertutil showcsr || printf "y\n" | seccertutil genkey -keysize 2048; seccertutil gencsr -hash sha1 -country US -state "New Jersey" -locality Edison -org Allianz -orgunit Storage -cn NAME.sma.cmsalz.ibm.allianz && seccertutil showcsr'

HOSTNAME=$1

[ -z "${HOSTNAME%%dee1*}" ] && echo "${E1}"
[ -z "${HOSTNAME%%fre2*}" ] && echo "${E2}"
[ -z "${HOSTNAME%%usn1*}" ] && echo "${N1}"
[ -z "${HOSTNAME%%usn2*}" ] && echo "${N2}"



