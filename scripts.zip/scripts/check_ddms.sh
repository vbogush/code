/usr/bin/bash

for i in `ls dscli/profile/ | sort`; do echo $i; dscli -cfg $i lsddm -state not_normal; done
