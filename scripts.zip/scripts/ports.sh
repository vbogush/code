#!/bin/bash

if [ $# -ne 2 ]; then

  echo "Please input in the format ./ports.sh dee1sans11ccpl1 e1_sans11_tmp";
  exit 1;

fi

SWITCH=$1;
FILE=$2;

echo "$SWITCH; $FILE";
echo $SWITCH >> "${SWITCH}_lw_ports.txt";
for i in `cat $FILE`; do echo "Port $i" >> "${SWITCH}_lw_ports.txt"; alz_conn.sh $SWITCH portshow $i|grep -E "^portName|^portHealth|^portSpeed" >> "${SWITCH}_lw_ports.txt"; echo >> "${SWITCH}_lw_ports.txt"; done
