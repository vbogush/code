#!/bin/bash

if [ $# -lt 2 ] ; then
        echo 'usage: checksum.sh filename checksum'
        exit 1
elif [ `md5sum $1 | awk '{print $1}'` = $2 ] ; then
        echo "File is not corrupted. We are saved.";
else
        echo "File is corrupted.";
fi
