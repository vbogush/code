#!/bin/bash

#Script for changing users passwords in SAN switches in ALZ. Uses MarcinR alz_conn.sh and sys_bnauser.
#Script works starting from FOS v7.4.

echo "Enter the switch name and press Enter"

read SWNAME;

echo "Enter the user name which exist on the switch and for which you need to change password and press Enter"

read SWUSER;

echo "Enter new password for user and pres Enter"

read -s -r 'PASS';

if [ -z "$SWNAME" ] || [ -z "$SWUSER" ] || [ -z "$PASS" ]; then

  echo "Swith name, user or password was/were not inputed"
  exit 1  

else

alz_conn.sh $SWNAME 'passwdcfg --set -oldpasswd=1;passwd '$SWUSER' -new '"\"$PASS"\"';passwdcfg --set -oldpasswd=0'

# Uncomment below two rows if logging is needed and specified path and file name.

echo "$SWUSER@$SWNAME" >> passwd.txt
echo "$PASS" >> passwd.txt

fi
