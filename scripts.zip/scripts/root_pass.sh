#!/bin/bash

if [ $# -eq 0 ]; then
    
  echo "Switch name and password are missing";
  echo "Please input in the format ./root_pass.sh switch_name 'new_password'";
  exit 1;

fi

if [ -z "$1" ] || [ -z "$2" ]; then

  echo "Switch name or password was/were not inputed";
  exit 1;  

else

SWNAME=$1;
PASS="$2";


echo "$PASS";  #old one - '"\"$PASS"\"' to print '' ""\'$PASS"'"

alz_conn.sh $SWNAME 'passwdcfg --set -oldpasswd=1;passwdcfg --set -digits=0;passwd root -new '${PASS}';passwdcfg --set -oldpasswd=0;passwdcfg --set -digits=1';

#sshpass -p 'P@$$w0rd\n' ssh root@$SWNAME 'passwdcfg --set -oldpasswd=1;passwdcfg --set -digits=0;passwd root -new '''\'''$PASS''\'';passwdcfg --set -oldpasswd=0;passwdcfg --set -digits=1';


  echo "root@$SWNAME" >> passwd.txt;
  echo "$PASS" >> passwd.txt;

sshpass -p "$PASS" ssh root@$SWNAME 'ps -ef | grep xmalloc;exit';
fi
