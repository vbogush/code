#!/bin/bash

. ~/.allianz_settings

for i in dee1tpc011ccpwa fre2tpc011ccpwa usn1tpc011ccpwa usn2tpc011ccpwa; do
	echo ==== ditributing to $i ====
	smbclient -U sma/${LDAP_USER} "//${i}/e\$" ${LDAP_PASS} -D SATHC/tpchc/lib/expect/BROCADE -c "PROMPT no; mput *.exp"
	echo
done

