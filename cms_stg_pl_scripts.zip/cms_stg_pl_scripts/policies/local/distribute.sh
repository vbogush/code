#!/bin/bash

. ~/.allianz_settings

for i in dee1tpc011ccpwa dee1tpc021ccpwa fre2tpc011ccpwa fre2tpc021ccpwa usn1tpc011ccpwa usn2tpc011ccpwa; do
	echo ==== ditributing to $i ====
	smbclient -U sma/${LDAP_USER} "//${i}/e\$" ${LDAP_PASS} -D SATHC/tpchc/conf/policies/local -c "PROMPT no; mput *.pol"
	echo
done

#sshpass -p ${TPCADM_PASS} scp *.pol tpcadmin@zaprtpc011ccp8a:/cygdrive/e/IBM/tpchc/conf/policies/local/
