#!/bin/bash

. ~/.allianz_settings

for i in dee1tpc011ccpwa dee1tpc021ccpwa fre2tpc011ccpwa fre2tpc021ccpwa usn1tpc011ccpwa usn2tpc011ccpwa; do
	echo ==== ditributing to $i ====
	#smbclient -U sma/${LDAP_USER} "//10.17.80.42/e\$" ${LDAP_PASS} -D SATHC/tpchc/bin/expect
	smbclient -U sma/${LDAP_USER} "//${i}/e\$" ${LDAP_PASS} -D SATHC/tpchc/bin/expect -c "PROMPT no; mput *.vbs"
	echo
done

