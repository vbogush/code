#!/bin/bash

#echo -n "Are you sure you want to use this script? "; read

. ~/.allianz_settings

DATE=`date +"%Y%m%d"`

E1='seccertutil showcsr || printf "y\n" | seccertutil genkey -keysize 2048; seccertutil gencsr -hash sha1 -country DE -state Darmstadt -locality Frankfurt -org Allianz -orgunit Storage -cn NAME.sma.cmsalz.ibm.allianz && seccertutil showcsr'
E2='seccertutil showcsr || printf "y\n" | seccertutil genkey -keysize 2048; seccertutil gencsr -hash sha1 -country FR -state Ile-de-France -locality Paris -org Allianz -orgunit Storage -cn NAME.sma.cmsalz.ibm.allianz && seccertutil showcsr'
N1='seccertutil showcsr || printf "y\n" | seccertutil genkey -keysize 2048; seccertutil gencsr -hash sha1 -country US -state Arizona -locality Phoenix -org Allianz -orgunit Storage -cn NAME.sma.cmsalz.ibm.allianz && seccertutil showcsr'
N2='seccertutil showcsr || printf "y\n" | seccertutil genkey -keysize 2048; seccertutil gencsr -hash sha1 -country US -state "New Jersey" -locality Edison -org Allianz -orgunit Storage -cn NAME.sma.cmsalz.ibm.allianz && seccertutil showcsr'

HOSTNAME=$1

[ -z "${HOSTNAME%%dee1*}" ] && CMD=${E1}
[ -z "${HOSTNAME%%fre2*}" ] && CMD=${E2}
[ -z "${HOSTNAME%%usn1*}" ] && CMD=${N1}
[ -z "${HOSTNAME%%usn2*}" ] && CMD=${N2}

[ -z "${CMD}" ] && exit
CMD=${CMD/NAME/${HOSTNAME}}

TF=`mktemp`
alz_conn.sh ${HOSTNAME} "${CMD}" | tee ${TF}

[ -s "${TF}" ] && ( cat ${TF} | awk '/BEGIN/ { p=1 } // { if(p) print } /END/ { p=0 }' > ${HOSTNAME}".csr" )

rm ${TF}

