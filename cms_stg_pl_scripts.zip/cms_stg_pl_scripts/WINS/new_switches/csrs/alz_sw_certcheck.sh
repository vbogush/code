#!/bin/bash

STOP_ON_ERR=0

. ~/allianz_storage_scripts/bin/functions

echo "Checking for SSL connectivity"
for i in `cat ${ETCDIR}/alz_sw_all.lst ${ETCDIR}/alz_svc_all.lst ${ETCDIR}/alz_v7s_all.lst ${ETCDIR}/alz_v5s_all.lst`; do
	echo -ne "${i}\t"
	echo exit | openssl s_client -connect ${i}:443 2>/dev/null | grep -E "issuer=.*O=Allianz.*Allianz" >/dev/null && STAT=OK || STAT=NOK
	echo ${STAT}
	if [ "x${STAT}" == "xNOK" ]; then
		echo -e "\tCert requests:"
		find -type f -name "$i*" | grep cert-req- || echo None
		echo -e "\tCerts:"
		find -type f -name "$i*" | grep certs- || echo None
	fi
done
