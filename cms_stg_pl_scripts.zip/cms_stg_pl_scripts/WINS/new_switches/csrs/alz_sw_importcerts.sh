#!/bin/bash

echo -n "Are you sure you want to use this script? "; read

(
for i in `cat ../etc/alz_sw_all_eu.lst add_e1 | grep "^dee1"`; do
	./alz_sw_importcerts.exp ${i} 10.17.80.43
done

for i in `cat ../etc/alz_sw_all_eu.lst add_e2 | grep "^fre2"`; do
	./alz_sw_importcerts.exp ${i} 10.72.80.43
done

for i in `cat ../etc/alz_sw_all_us.lst add_n1 | grep "^usn1"`; do
	./alz_sw_importcerts.exp ${i} 10.86.162.43
done

for i in `cat ../etc/alz_sw_all_us.lst add_n2 | grep "^usn2"`; do
	./alz_sw_importcerts.exp ${i} 10.118.162.43
done
) | tee -a alz_sw_importcerts.log
