#!/bin/bash

LINK=`readlink $0` || LINK=$0
DIR=`dirname $LINK`

. ~/allianz_storage_scripts/bin/functions

LIST="list"

for i in `cat ${LIST}`; do
	./set_passwords.exp ${i}
done | tee password
