#!/bin/bash

LINK=`readlink $0` || LINK=$0
DIR=`dirname $LINK`
. ~/allianz_storage_scripts/bin/functions

SW=$1

[ "x${SW}" == "x" ] && exit

helpers/set_passwords.exp ${SW}
conn ${SW} "switchcfgpersistentenable; ag --pgsetmode 0 lb; ag --show | grep san"
