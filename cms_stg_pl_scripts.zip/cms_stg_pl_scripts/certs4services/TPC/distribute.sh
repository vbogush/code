#!/bin/bash

. ~/.allianz_settings

echo distributing key.jks for SATHC
for i in dee1tpc011ccpwa dee1tpc021ccpwa fre2tpc011ccpwa fre2tpc021ccpwa usn1tpc011ccpwa usn2tpc011ccpwa; do
	smbclient -U sma/${LDAP_USER} "//${i}/e\$" ${LDAP_PASS} -D SATHC/tpchc/wlp/usr/servers/PDT/resources/security -c "prompt no; put key-sathc.jks key.jks"
done

echo distributing key.jks for SC
smbclient -U sma/${LDAP_USER} "//dee1tpc011ccpwa/e\$" ${LDAP_PASS} -D 'Program Files/IBM/TPC/wlp/usr/servers/webServer/resources/security' -c "prompt no; put key-sc_e1_tpc1.jks key.jks"
smbclient -U sma/${LDAP_USER} "//dee1tpc021ccpwa/e\$" ${LDAP_PASS} -D 'Program Files/IBM/TPC/wlp/usr/servers/webServer/resources/security' -c "prompt no; put key-sc_e1_tpc2.jks key.jks"
smbclient -U sma/${LDAP_USER} "//fre2tpc011ccpwa/e\$" ${LDAP_PASS} -D 'Program Files/IBM/TPC/wlp/usr/servers/webServer/resources/security' -c "prompt no; put key-sc_e2_tpc1.jks key.jks"
smbclient -U sma/${LDAP_USER} "//fre2tpc021ccpwa/e\$" ${LDAP_PASS} -D 'Program Files/IBM/TPC/wlp/usr/servers/webServer/resources/security' -c "prompt no; put key-sc_e2_tpc2.jks key.jks"
smbclient -U sma/${LDAP_USER} "//usn1tpc011ccpwa/e\$" ${LDAP_PASS} -D 'Program Files/IBM/TPC/wlp/usr/servers/webServer/resources/security' -c "prompt no; put key-sc_n1_tpc1.jks key.jks"
smbclient -U sma/${LDAP_USER} "//usn2tpc011ccpwa/e\$" ${LDAP_PASS} -D 'Program Files/IBM/TPC/wlp/usr/servers/webServer/resources/security' -c "prompt no; put key-sc_n2_tpc1.jks key.jks"

echo distributing key.jks for Cognos Connection
for i in dee1tpc011ccpwa fre2tpc011ccpwa usn1tpc011ccpwa usn2tpc011ccpwa; do
		smbclient -U sma/${LDAP_USER} "//${i}/e\$" ${LDAP_PASS} -D 'Program Files\IBM\JazzSM\profile\config\cells\JazzSMNode01Cell\nodes\JazzSMNode01' -c "prompt no; put trust.p12"
		smbclient -U sma/${LDAP_USER} "//${i}/e\$" ${LDAP_PASS} -D 'Program Files\IBM\JazzSM\profile\etc' -c "prompt no; put trust.p12"
done
smbclient -U sma/${LDAP_USER} "//dee1tpc011ccpwa/e\$" ${LDAP_PASS} -D 'Program Files\IBM\JazzSM\profile\config\cells\JazzSMNode01Cell\nodes\JazzSMNode01' -c "prompt no; put key-cogcon_e1-tpc1.p12 key.p12"
smbclient -U sma/${LDAP_USER} "//fre2tpc011ccpwa/e\$" ${LDAP_PASS} -D 'Program Files\IBM\JazzSM\profile\config\cells\JazzSMNode01Cell\nodes\JazzSMNode01' -c "prompt no; put key-cogcon_e2-tpc1.p12 key.p12"
smbclient -U sma/${LDAP_USER} "//usn1tpc011ccpwa/e\$" ${LDAP_PASS} -D 'Program Files\IBM\JazzSM\profile\config\cells\JazzSMNode01Cell\nodes\JazzSMNode01' -c "prompt no; put key-cogcon_n1-tpc1.p12 key.p12"
smbclient -U sma/${LDAP_USER} "//usn2tpc011ccpwa/e\$" ${LDAP_PASS} -D 'Program Files\IBM\JazzSM\profile\config\cells\JazzSMNode01Cell\nodes\JazzSMNode01' -c "prompt no; put key-cogcon_n2-tpc1.p12 key.p12"

echo distributing key.jks for Cognos Analytics
for i in dee1tpc021ccpwa fre2tpc021ccpwa; do
	smbclient -U sma/${LDAP_USER} "//${i}/e\$" ${LDAP_PASS} -D 'Program Files\IBM\cognos\analytics\bin64' -c "prompt no; put ../ca.p7b ca.p7b"
	echo on $i run \(d:/Program Files/IBM/cognos/analytics/bin\): ./ThirdPartyCertificateTool.bat -i -T -r ca.p7b -p NoPassWordSet
done
smbclient -U sma/${LDAP_USER} "//dee1tpc021ccpwa/e\$" ${LDAP_PASS} -D 'Program Files\IBM\cognos\analytics\configuration\certs' -c "prompt no; put dee1tpc021ccpwa.p12"
smbclient -U sma/${LDAP_USER} "//fre2tpc021ccpwa/e\$" ${LDAP_PASS} -D 'Program Files\IBM\cognos\analytics\configuration\certs' -c "prompt no; put fre2tpc021ccpwa.p12"

