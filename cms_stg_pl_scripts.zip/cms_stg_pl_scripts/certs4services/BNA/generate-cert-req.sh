#!/bin/bash

. ~/allianz_storage_scripts/bin/functions

for bna in `grep bna ${ETCDIR}/hosts.in | awk '{ print $1}' | sort -u`; do
	site=`echo ${bna} | cut -c 1-4`
	sed s/COMMON_NAME/${bna}.sma.cmsalz.ibm.allianz/ ${site}.cnf > tmp.cnf
	cat tmp.cnf
	openssl req -new -newkey rsa:2048 -nodes -sha256 -keyout ${bna}.key -out ${bna}.csr
	rm tmp.cnf
done
