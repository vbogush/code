#!/bin/bash

FILE="20180125_extract_alzsid_to_roles.csv"

SW_CMS="alz_sw_all.lst admin root"
SW_SO="alz_sw_all.lst souser"

V5_CMS="alz_v5s_all.lst superuser"
V7_CMS="alz_v7s_all.lst superuser"
SVC_CMS="alz_svc_all.lst superuser"

DS8_CMS="alz_ds8k_all.lst admin backup_admin customer"

XIV_CMS="alz_xiv_all.lst admin"

F9S_CMS="alz_f9s_all.lst superuser"

G08_CMS="alz_g08_all.lst maintenance"
G15_CMS="alz_g15_all.lst maintenance"


for i in SW_CMS V5_CMS V7_CMS SVC_CMS DS8_CMS XIV_CMS F9S_CMS G08_CMS G15_CMS; do
	read -a USERS <<< ${!i}
	LIST=${USERS[0]}
	USERS[0]=""
	GRS=$( echo ${USERS[*]} | sed 's/ /|/g' )
	for device in `cat ${HOME}/allianz_storage_scripts/etc/${LIST}`; do
		for user in ${USERS[*]}; do
			if `cat ${FILE} | grep -iw "$user@$device" >/dev/null`; then
			  echo "$user@$device  CRED_OK"
			else
			  echo -n "ITIM4U2	DE	P71624_820	"
			  [ "x${device##usn*}" == "x" ] && echo -n "DE-ALZ:SAN_NA_Password_Sharing" || echo -n "DE-ALZ:SAN_Password_Sharing"
			  echo "	ALZ	Allianz	DE-ALZ:VAULT		${device}	DPE		${user}	P71624_820	FALSE	ADD_MISSING_NOK"
			fi
		done
		cat ${FILE} | grep -i "@$device" | egrep -vi "	(${GRS})@$device	" | sed 's/	/;/g' > /tmp/tmp
		
		OLD_IFS=$IFS
		IFS=";"
		[ -e tmp/tmp ] && cat /tmp/tmp | while read -a X; do echo "ITIM4U2	DE	${X[2]}	${X[7]}	ALZ	Allianz	DE-ALZ:VAULT	${X[1]##*@}	${X[1]%%@*}	REMOVE"; done
		IFS=$OLD_IFS
	done
done

#for i in SW_SO; do
#	read -a USERS <<< ${!i}
#	LIST=${USERS[0]}
#	USERS[0]=""
#	GRS=$( echo ${USERS[*]} | sed 's/ /|/g' )
#	for device in `cat ${HOME}/allianz_storage_scripts/etc/${LIST}`; do
#		for user in ${USERS[*]}; do
#			echo -n "$user@$device  "
#      cat ${FILE} | grep -iw "$user@$device" >/dev/null && echo OK || echo NOK
#    done
#	done
#done
