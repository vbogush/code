#!/usr/bin/bash

do_restart() {
	SITE=`hostname | gawk -F "" '{print $1$2$3$4 }'`
	for i in `cat list | grep ${SITE} | awk '{ print $1 }'`; do
		echo checking $i
		ssh -o StrictHostKeyChecking=no -i sys_tpcuser sys_tpcuser@${i} 'echo ==== checking events on $clust; lseventlog -nohdr -message no -fixed no -filtervalue object_type=rc_consist_grp | while read -a X; do echo restarting rc_consist_grp=${X[4]}; startrcconsistgrp -force ${X[4]} && ( echo fixing event=${X[0]};cheventlog -fix ${X[0]} ); done; lseventlog -nohdr -message no -fixed no -filtervalue object_type=rc_relationship | while read -a X; do echo restarting rc_relationship=${X[4]}; startrcrelationship -force ${X[4]}; echo fixing event=${X[0]};cheventlog -fix ${X[0]}; done'
	done
}

cd `dirname $0`
(
#while [ 1 ]; do
#	echo entering into loop
	date
	do_restart
#	sleep 300
#done
) 2>&1 > ~/gm_restart.log
