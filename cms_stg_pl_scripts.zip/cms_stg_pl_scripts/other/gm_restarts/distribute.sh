#!/bin/bash

. ~/.allianz_settings

cat /etc/hosts | grep -E "(dee1|fre2|usn1|usn2)svcs......[a12]" > list

cat list

read
for i in dee1tpc011ccpwa fre2tpc011ccpwa usn1tpc011ccpwa usn2tpc011ccpwa; do
	echo ==== ditributing to $i ====
	smbclient -U ./tpcadmin "//${i}/e\$" "8bhAPBePR4hpvtU" -D SATHC/cygwin/home/tpcadmin -c "PROMPT no; mput *; rm distribute.sh"
	echo
done

