#!/bin/bash

. ~/.allianz_settings
for srv in dee1bna011ccp8a dee1bna021ccpwa fre2bna011ccp8a fre2bna021ccpwa usn1bna011ccp8a usn2bna011ccp8a; do
#	smbclient -U sma/${LDAP_USER} "//${srv}/d\$" ${LDAP_PASS} -D "Program Files/IBM Network Advisor 14.2.2/jre64/lib/security" -c "prompt no; put java.security"
#	smbclient -U sma/${LDAP_USER} "//${srv}/d\$" ${LDAP_PASS} -D "Program Files/IBM Network Advisor 14.2.2/jre/lib/security" -c "prompt no; put java.security"
	smbclient -U sma/${LDAP_USER} "//${srv}/d\$" ${LDAP_PASS} -D "Program Files/IBM Network Advisor 14.2.2/jboss/standalone/configuration" -c "prompt no; put standalone-dcm.xml"
done
