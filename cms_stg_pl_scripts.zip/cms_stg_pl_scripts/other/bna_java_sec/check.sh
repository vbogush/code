#!/bin/bash

nmap -sV -p 443 dee1bna011ccp8a --script ssl-enum-ciphers.nse
nmap -sV -p 443 fre2bna011ccp8a --script ssl-enum-ciphers.nse
