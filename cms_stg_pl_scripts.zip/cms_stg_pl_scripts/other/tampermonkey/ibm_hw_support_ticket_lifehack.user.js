// ==UserScript==
// @name         IBM HW support ticket - change behavior of some fields
// @namespace    http://biczan.pl/
// @version      0.1
// @description  Change behavior
// @author       marcin.biczan@pl.ibm.com
// @match        https://www-947.ibm.com/support/servicerequest/newServiceRequest.action
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var myFunc = function() {
        ['zip', 'phone', 'hardware.problemInfo.errorCode', 'hardware.problemInfo.customerProblemNumber'].forEach(function(fieldName) {
            var elem = document.getElementById(fieldName);
            if( elem ) {
                console.log('IBM HW support ticket - change behavior of some fields :: changing ' + fieldName);
                elem.removeAttribute('onpaste');
                elem.removeAttribute('autocomplete');
            };
        });
        if( document.getElementById('custName') ) {
            var locName = document.getElementById('sr-form-1-name').innerText;
            var custName = document.getElementById('custName').value;

            if( custName == 'AMOS SE CHEZ INER' ) {
                if( locName == 'Germany' ) {
                    document.getElementById('address').value = 'Eschborner Landstraße 100';
                    document.getElementById('city').value = 'Frankfurt';
                    document.getElementById('zip').value = '60489';
                    document.getElementById('phone').value = '+49 69 78012110';
                }
                else if( locName == 'France') {
                    document.getElementById('address').value = '1-3 Rue Rateau';
                    document.getElementById('city').value = 'Paris';
                    document.getElementById('zip').value = '93120';
                    document.getElementById('phone').value = '+33 (0) 81063 1213';
                }
            } else if( custName == 'Allianz AMOSA' ){
                if( document.getElementById('city').value == 'Phoenix' ) {
                    document.getElementById('address').value = '615 N 48 Street';
                    document.getElementById('zip').value = '85008';
                    document.getElementById('custState').selectedIndex = 3;
                    document.getElementById('phone').value = '646-413-4191';
                    document.getElementById('extension').value = '37697';
                } else if( document.getElementById('city').value == 'Edison' ) {
                    document.getElementById('address').value = '3003 Woodbridge Ave';
                    document.getElementById('zip').value = '08837';
                    document.getElementById('custState').selectedIndex = 32;
                    document.getElementById('phone').value = '646-413-4191';
                }
            }
        }
        if( document.getElementById('contactName') && document.getElementById('contactName').value == 'CMSSTGPL' ) {
            document.getElementById('contactEmail').value='cmsstgpl@pl.ibm.com';
            document.getElementById('contactPhone').value='0048727062868';
        }
    };
    document.onsubmit = myFunc
    document.onchange = myFunc
})();
