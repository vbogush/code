#!/bin/bash

. ~/.allianz_settings

cd "Query Studio Reports"
for i in dee1tpc011ccpwa fre2tpc011ccpwa dee1tpc021ccpwa fre2tpc021ccpwa usn1tpc011ccpwa usn2tpc011ccpwa; do
	echo ==== ditributing to $i ====
	smbclient -U sma/${LDAP_USER} "//${i}/e\$" ${LDAP_PASS} -D "/Program Files/IBM/JazzSM/reporting/cognos/deployment" -c "PROMPT no; mput *.zip"
	echo
done

