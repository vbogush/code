#!/bin/bash

die() {
	echo [E] $*
	exit 1
}

debug() {
	echo [D] $*
}

ask() {
	echo -n [?] $*
	read
}

[ `whoami` == 'root' ] && die "root not allowed !!!"

PWD=`pwd`
DIR=`dirname $0`

cat >&2 <<EOF
==============================================================================================================================================================
© 2017 IBM. All rights reserved. Sample scripts in this guide are not supported under any IBM standard support program or service. The sample scripts are
provided AS IS without warranty of any kind. IBM disclaims all implied warranties including, without limitation, any implied warranties of merchantability or
of fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. In no
event shall IBM, its authors, or anyone else involved in the creation, production, or delivery of the scripts be liable for any damages whatsoever (including,
without limitation, damages for loss of business profits, business interruption, loss of business information, or other pecuniary loss) arising out of the
use of or inability to use the sample scripts or documentation, even if IBM has been advised of the possibility of such damages.
==============================================================================================================================================================
Script by Marcin Biczan <marcin.biczan@pl.ibm.com>

Please press enter to proceed
EOF
read

debug "My dir: $PWD/$DIR/"

. $PWD/$DIR/etc/definitions

debug "Setting up ${TEAM} Storage scripts"
echo
debug 'Checking bashrc file for correct PATH settings'
cat ~/.bashrc | grep ${SCRIPTS_PATH} > /dev/null || echo 'export PATH=$PATH:~/'${SCRIPTS_PATH}'/bin' >> ~/.bashrc
cat ~/.bashrc | grep "complete -A hostname conn" > /dev/null || echo 'complete -A hostname conn' >> ~/.bashrc
cat ~/.bashrc | grep "complete -A hostname alz_conn.sh" > /dev/null || echo 'complete -A hostname alz_conn.sh' >> ~/.bashrc
if [ "x$PWD" != "x$HOME/${SCRIPTS_PATH}" ]; then
	debug 'Removing old allianz_storage_scripts'; rm ${HOME}/${SCRIPTS_PATH} 2>/dev/null
	debug 'Linking new allianz_storage_scripts'; ln -s $PWD/$DIR/ ${HOME}/${SCRIPTS_PATH}
fi

debug Checking for ~/.allianz_settings file
if [ ! -f ~/.allianz_settings ]; then
	debug File ~/.allianz_settings doesn\'t exist. Creating temaplate - please edit this file for automation!!!
	touch ~/.allianz_settings
	debug Please unhash lines and pass Your SMA username and password
else
	debug File ~/.allianz_settings exists
	cat ~/.allianz_settings
	ask "Please check if all credentials are present (example in ~/.allianz_settings.template). if not please edit the file!!! (press enter)"
fi
debug Creating ~/.allianz_settings.template file
cat > ~/.allianz_settings.template << EOF
LDAP_USER=''
LDAP_PASS='''
GSNI_USER=''
GSNI_PASS=''
SCEPSSM_USER=''
SCEPSSM_PASS=''
SCEPSSMSTG_USER=''
SCEPSSMSTG_PASS=''
SCEPLOCAL_USER=''
SCEPLOCAL_PASS=''
EOF

debug "Checking for XCLI at location /opt/IBM_XIV_Storage_Management_GUI/xcli";
if [ -f /opt/IBM_XIV_Storage_Management_GUI/xcli ]; then
	[ -f bin/xcli ] && rm -rf bin/xcli bin/xivgui bin/xivtop
	ln -s /opt/IBM_XIV_Storage_Management_GUI/xcli bin
	ln -s /opt/IBM_XIV_Storage_Management_GUI/xivgui bin
	ln -s /opt/IBM_XIV_Storage_Management_GUI/xivtop bin
	debug "XCLI linked to bin folder"
else
	debug "XCLI not found - please run: ln -s <XCLI location> bin"
fi

debug "Checking for DSCLI at location /opt/ibm/dscli/dscli";
if [ -f /opt/ibm/dscli/dscli ]; then
	[ -f bin/dscli ] && rm -rf bin/dscli
	ln -s /opt/ibm/dscli/dscli bin
	debug "DSCLI linked to bin folder"
else
	debug "DSCLI not found - please run: ln -s <DSCLI location> bin"
fi

debug "Preparing etc files"; ( cd etc; ( make clean; make all ) 2>&1 >/dev/null )
debug "Preparing hosts file - please enter Your password to replace /etc/hosts file"; ( cd bin; ./make_hosts.sh )
debug "Installing Allianz CA certificates"; ( cd certs4services; sudo cp *.der /usr/share/pki/ca-trust-source/anchors/; sudo update-ca-trust )

debug "Cleaning logs"; find logs/ -type f -mtime +30 -exec rm -rf {} \;
touch logs/.holder
