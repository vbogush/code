#!/usr/bin/python

import json, os, re

CMDB = open("ci.json", "r")
cmdb = json.load(CMDB)
CMDB.close()

#print "[D] CMDB loaded: %s" % (cmdb['CIMboSet']['rsCount'])
cmdb_set = set()

for device in cmdb['CIMboSet']['CI']:
    cmdb_set.add(device['CINAME'].lower())

files = os.listdir('.')
CI_checked = set()
print "Hostname|IP Address|Machine Type|Model|Serial number|DC|Location"
for f in files:
    if( f.find('sc-') == 0 ):
        F = open(f, "r")
        CIs = json.load(F)
        F.close

#        print json.dumps(CIs, sort_keys=True, indent=4, separators=(',', ': '))
        for CI in CIs:
            ci_name = re.split(' |_', CI['Name'])[0].lower()
            if re.match("dee1|fre2|usn1|usn2", ci_name) and ci_name not in CI_checked and ci_name not in cmdb_set:
#                print json.dumps(CI, sort_keys=True, indent=4, separators=(',', ': '))
#                print "Name:[%s] IP:[%s] Serial:[%s] Location:[%s] #source:%s" % (CI['Name'], CI['IP Address'], CI['Serial Number'], CI['Location'], f)
                if re.match("^dee1", CI['Name']):
                    dc = "Franfurt"
                elif re.match("^fre2", CI['Name']):
                    dc = "Paris"
                elif re.match("^usn1", CI['Name']):
                    dc = "Phoenix"
                elif re.match("^usn2", CI['Name']):
                    dc = "Edison"
                else:
                    dc = "Unknown"

                if 'Type' in CI:
                    ci_type = CI['Type']
                else:
                    ci_type = CI['Model']
                    CI['Model'] = ""
                print "%s|%s|%s|%s|%s|%s|%s" % (CI['Name'], CI['IP Address'], ci_type, CI['Model'], CI['Serial Number'], dc, CI['Location'])

            CI_checked.add(ci_name)
            CI['PYchecked'] = 1

with open('hosts.in') as f:
    lines = f.read().splitlines()
    for line in lines:
        CI = re.split(' |\t', line)
        ci_name = CI[0]
        if re.match("^dee1", ci_name):
            dc = "Franfurt"
        elif re.match("^fre2", ci_name):
            dc = "Paris"
        elif re.match("^usn1", ci_name):
            dc = "Phoenix"
        elif re.match("^usn2", ci_name):
            dc = "Edison"
        else:
            dc = "Unknown"

        if re.match("dee1|fre2|usn1|usn2", ci_name) and not re.match("....(ass|bna|tpc)", ci_name) and ci_name not in CI_checked and ci_name not in cmdb_set:
#            print "Name:[%s] IP:[%s] #source:%s" % (ci_name, CI[1], "hosts.in")
            print "%s|%s||||%s|" % (CI[0], CI[1], dc)

        CI_checked.add(ci_name)

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4
