#!/bin/bash

. ~/.allianz_settings

wget --no-check-certificate --user=${LDAP_USER}"@sma.cmsalz.ibm.allianz" --password="${LDAP_PASS}" 'https://10.17.79.141:9443/maxrest/rest/mbo/ci/?_compact=1&_format=json&CLASSSTRUCTUREID=DW-210000020,DW-210000081' -O - | tee ci.json
