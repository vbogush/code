#!/usr/bin/python

import requests, json, sys, time,os, datetime, thread,re, getpass, os, re
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from pprint import pprint
from optparse import OptionParser

SCservs = { "dee1tpc011ccpwa",
        # "dee1tpc021ccpwa",
        "fre2tpc011ccpwa",
        # "fre2tpc021ccpwa",
        "usn1tpc011ccpwa",
        "usn2tpc011ccpwa" }

#FORMAT
formatjson = "&_format=json&_compact=1&_exactmatch=False"

def badinputexit():
    print('User or password can not be blank. Program abort.')
    sys.exit()

def message(title, message):
    os.system('notify-send "'+title+'" "'+message+'"')

def perr(s):
    print str(datetime.datetime.now()) + ' [E] ' + s
#    message("error", s)

def pinfo(s):
    print str(datetime.datetime.now()) + ' [I] ' + s
#    message("info", s)

def pdeb(s):
    print str(datetime.datetime.now()) + ' [D] ' + s
#    message("debug", s)

def scauth():
    global username, password

    print ("Authentication")
    if( username == "" ):
        uinput = raw_input("user: ")
        if uinput == '' :
            badinputexit()
        username = uinput
    if( password == "" ):
        pinput = getpass.getpass(prompt='password: ')
        if pinput == '':
            badinputexit()
        password = pinput

def getJSONData (requestString):
    global session

    if requestString == "":
        perr("blank request")
        sys.exit()
    else:
        try:
#            print requestString
            r = session.get(requestString, verify=False)
            if r.status_code == 200:
                requestedData = json.loads(r.text)
                return requestedData
            else:
                badmsg = "SERVER CONNECTION ERROR" + str(r.status_code) + "/n REASON: " + str(r.reason)
                perr(badmsg)
                return None

        except requests.exceptions.ConnectionError:
            networkerr = str(datetime.datetime.now()) + " NETWORK ERROR 101, 'Network is unreachable trying again"
            perr(networkerr)

def postData(dataRequestString, dataString):
    global session

    try:
        r = session.post(dataRequestString, data=dataString, verify=False)

        if r.status_code == 200 and session.cookies['LtpaToken2']:
            return True
        else:
            print ("ERORR \nSERVER RETURN "+str(r.status_code)+"\n"+r.reason+"\nPOST REQUEST unsucceful \n" + r.content)
            message ("error", "ERORR \n SERVER RETURN "+str(r.status_code)+"\n "+r.reason+"\n POST REQUEST unsucceful")
            return False


    except requests.exceptions.ConnectionError:
        networkerr = str(datetime.datetime.now()) + " NETWORK ERROR 101, 'Network is unreachable trying again"
        print networkerr
        #message("error", networkerr)
        return False

def main():
    global username, password, SCservs, session

    parser = OptionParser()
    parser.add_option("-U", "--user", action="store", type="string", default="", dest="username", help="SC username")
    parser.add_option("-P", "--pass", action="store", type="string", default="", dest="password", help="SC password")

    (options, args) = parser.parse_args()

    username = options.username
    password = options.password

    if( username=="" or password=="" ):
        scauth()

    for srv in SCservs:
        print srv
        session = requests.Session()
        url = "https://" + srv + ":9569/srm/"
        authurl = url + "j_security_check"
        storqryurl = url + 'REST/api/v1/StorageSystems'
        switchqryurl = url + 'REST/api/v1/Switches'

        AuthData = { "j_username": username, "j_password": password }
        if( not postData(authurl, AuthData) ):
            perr("Wrong username or password provided!")
            sys.exit(-2)

        data = getJSONData(storqryurl + '?' + formatjson)
        F = open('sc-' + srv + '-stor.json', 'w')
        F.write(json.dumps(data, sort_keys=True, indent=4, separators=(',', ': ')))
        F.close()

#        F = open('sc-' + srv + '-stornodes.json', 'w')
#        CIs = data
#        final_list = []
#        for CI in CIs:
#            data = getJSONData(storqryurl + '/' + CI['id'] + '/Nodes?' + formatjson)
#            final_list.append(data)
#        F.write(json.dumps(final_list, sort_keys=True, indent=4, separators=(',', ': ')))
#        F.close()

        data = getJSONData(switchqryurl + '?' + formatjson)
        F = open('sc-' + srv + '-sw.json', 'w')
        F.write(json.dumps(data, sort_keys=True, indent=4, separators=(',', ': ')))
        F.close()

#        F = open('sc-' + srv + '-swnodes.json', 'w')
#        CIs = data
#        final_list = []
#        for CI in CIs:
#            data = getJSONData(storqryurl + '/' + CI['id'] + '/Nodes?' + formatjson)
#            final_list.append(data)
#        F.write(json.dumps(final_list, sort_keys=True, indent=4, separators=(',', ': ')))
#        F.close()

        session.close()

if __name__ == '__main__':
    main()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4
