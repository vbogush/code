#!/usr/bin/python

import xlrd
import numpy as np
import sys

def check_if_exists(arr, hn):
    return any(x[0] == hn for x in arr)

def get_hostname(arr, ip):
    for x in arr:
        if x[1] == ip:
            return x[0]
    return None

hosts_in = np.genfromtxt('hosts.in', delimiter='\t', usecols=(0, 1), skip_footer=1, dtype=None)
workbook = xlrd.open_workbook("ALZ_SLA042705_M_CMDB_Completeness_And_Conformity_SAN_20180502.xlsx")

found_hosts = set()

xl_sheet = workbook.sheet_by_name("SAN ARRAY Details")
num_cols = xl_sheet.ncols

for row_idx in range(2, xl_sheet.nrows):
    hostname = xl_sheet.cell(row_idx, 10)
    ip_address = xl_sheet.cell(row_idx, 16)
    hh = get_hostname(hosts_in, ip_address.value)
    comment = 'OK'
    found_hosts.add(hostname.value)
    if not hh:
        comment = 'unknown ip address (device out of CMS Storage scope?)'
    elif hh != hostname.value:
        comment = 'hostname has to corrected to "%s"' % (hh)
        found_hosts.add(hh)

    print ('%s	%s	%s' % (hostname.value, ip_address.value, comment))

xl_sheet = workbook.sheet_by_name("Storage_Switch Details")
num_cols = xl_sheet.ncols

for row_idx in range(2, xl_sheet.nrows):
    hostname = xl_sheet.cell(row_idx, 14)
    ip_address = xl_sheet.cell(row_idx, 10)
    hh = get_hostname(hosts_in, ip_address.value)
    comment = 'OK'
    found_hosts.add(hostname.value)
    if not hh:
        comment = 'unknown ip address (device out of CMS Storage scope?)'
    elif hh != hostname.value:
        comment = 'hostname has to corrected to "%s"' % (hh)
        found_hosts.add(hh)

    print ('%s	%s	%s' % (hostname.value, ip_address.value, comment))

xl_sheet = workbook.sheet_by_name("SAN Virtualization Details")
num_cols = xl_sheet.ncols

for row_idx in range(2, xl_sheet.nrows):
    hostname = xl_sheet.cell(row_idx, 4)
    if check_if_exists(hosts_in, hostname.value):
        comment = 'OK'
    else:
        comment = 'unknown hostname (device out of CMS Storage scope?)'

    print ('%s		%s' % (hostname.value, comment))

xl_sheet = workbook.sheet_by_name("SAN Volume Controller Details")
num_cols = xl_sheet.ncols

for row_idx in range(2, xl_sheet.nrows):
    hostname = xl_sheet.cell(row_idx, 16)
    ip_address = xl_sheet.cell(row_idx, 12)
    hh = get_hostname(hosts_in, ip_address.value)
    comment = 'OK'
    found_hosts.add(hostname.value)
    if not hh:
        comment = 'unknown ip address (device out of CMS Storage scope?)'
    elif hh != hostname.value:
        comment = 'hostname has to corrected to "%s"' % (hh)
        found_hosts.add(hh)

    print ('%s	%s	%s' % (hostname.value, ip_address.value, comment))

for x in hosts_in:
    if not check_if_exists(found_hosts, x[0]):
        print ('%s  %s  Device not in CMDB but should' % (x[0], x[1]))
