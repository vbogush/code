This project includes scripts framework used by CMS-STG-PL team.

Installation procedure available under:
https://w3-connections.ibm.com/wikis/home?lang=en-us#!/wiki/Wc9afb6fd51ad_470b_9fce_42a4c8bcdd41/page/Scripts